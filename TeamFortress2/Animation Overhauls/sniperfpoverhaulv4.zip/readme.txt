This is a cosmetic skin that replaces the Sniper's first person animations with new ones I made. 
It works properly with both viewmodel fov 54 through 90.

If you want to use this on valve servers, try this.
https://steamcommunity.com/groups/PaysusSkins#announcements/detail/289752338002823917

Compatible with:
Realistic Bolt Overhaul: https://gamebanana.com/skins/165931
70 FOV Fix Pack (fixes snipers gloves): https://gamebanana.com/skins/124706

If it doesn't work, make sure it's not being overwritten by another mod you have.
If it is, simply rename 'Sniper FP Anim Overhaul.VPK' to '0A Sniper FP Anim Overhual.VPK'
This will ensure it's read by the game before other mods.

For updates and questions, the best way to contact me is through discord.
My server invite is MSf9T6Q. You can also email me at prophetpaysus@gmail.com.
Please don't sign me up for pornhub.